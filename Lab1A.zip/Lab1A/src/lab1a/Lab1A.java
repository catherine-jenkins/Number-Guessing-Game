package lab1a;
import java.util.Scanner;

public class Lab1A {

    public static void main(String[] args) {

       System.out.println("I am thinking of a number between 1 and 100.");
       System.out.println("Please guess a number: ");
       
       Scanner inputNumber = new Scanner(System.in);
       
       int numberOfGuesses = 1;
       int correctNumber = (int)(Math.random() * 100) + 1;
       int guessedNumber;
       
       guessedNumber = inputNumber.nextInt(); 
       
       while (guessedNumber != correctNumber){
           
            numberOfGuesses++;
            if (guessedNumber > correctNumber)
                System.out.println(guessedNumber + " is too high. Please guess again.");

            else if (guessedNumber < correctNumber)
                System.out.println(guessedNumber + " is too low. Please guess again.");
            
            guessedNumber = inputNumber.nextInt();

       }
       System.out.println("Congratulations! You guessed the number in " + numberOfGuesses + " guess(es)!");
    }
        
}
   
       
               
    
    

